module.exports = {
    AWS_REGION:"ap-south-1",
    AWS_ACCESS_KEY_ID:"AKIA5FTZDGN4AUQRWTFC",
    AWS_SECRET_ACCESS_KEY:"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",
    AWS_BUCKET_NAME:"ied-test",
}